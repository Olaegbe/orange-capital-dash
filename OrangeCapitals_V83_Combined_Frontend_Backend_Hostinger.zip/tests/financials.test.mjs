import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateSimpleMonthlyLoan, calculateRollover, getLoanOutstanding, getRecordedPayments, parseNaira, isLoanDisbursed } from '../src/lib/financials.js';

test('simple monthly interest, fee deduction and whole-naira policy', () => {
  assert.deepEqual(calculateSimpleMonthlyLoan({ principal: 5_000_000, monthlyRatePercent: 10, durationMonths: 3, processingFee: 100_000 }), {
    valid: true, principal: 5_000_000, monthlyRatePercent: 10, durationMonths: 3, processingFee: 100_000,
    totalInterest: 1_500_000, totalPayable: 6_500_000, netDisbursement: 4_900_000,
  });
});
test('rejects invalid values and fees greater than principal', () => {
  assert.equal(calculateSimpleMonthlyLoan({ principal: 0, monthlyRatePercent: 10, durationMonths: 1 }).valid, false);
  assert.equal(calculateSimpleMonthlyLoan({ principal: 100, monthlyRatePercent: 10, durationMonths: 1, processingFee: 101 }).valid, false);
  assert.equal(calculateSimpleMonthlyLoan({ principal: 100, monthlyRatePercent: 10, durationMonths: 1, processingFee: 100 }).valid, false);
  assert.equal(parseNaira('1,2,3'), Number.NaN);
});
test('reconciles legacy amountPaid against payment history without double-counting', () => {
  const loan = { principal: 5_000_000, totalPayable: 6_500_000, disbursed: true, amountPaid: '₦1,000,000', balance: '₦5,500,000', paymentHistory: [{ amountNumber: 500_000 }] };
  assert.equal(getRecordedPayments(loan), 1_000_000);
  assert.equal(getLoanOutstanding(loan), 5_500_000);
});
test('uses payment history as source of truth when it exceeds legacy total', () => {
  const loan = { totalPayable: 1_000, disbursed: true, amountPaid: '₦200', paymentHistory: [{ amountNumber: 300 }, { amount: '₦100' }] };
  assert.equal(getRecordedPayments(loan), 400);
  assert.equal(getLoanOutstanding(loan), 600);
});
test('parses properly grouped naira amounts', () => {
  assert.equal(parseNaira('₦1,234,567'), 1_234_567);
  assert.equal(parseNaira('12,000.50'), 12_000.5);
});

test('financial totals include only loans explicitly confirmed as disbursed', () => {
  assert.equal(isLoanDisbursed({ disbursed: true }), true);
  assert.equal(isLoanDisbursed({ disbursed: false, status: 'Pending' }), false);
  assert.equal(isLoanDisbursed({ status: 'Active' }), false);
  assert.equal(isLoanDisbursed({ disbursementDate: '2026-10-13' }), false);
});


test('rollover balance is reduced only by payments in the current rollover period', () => {
  const loan = {
    disbursed: true,
    totalPayable: 1_500,
    balance: '₦1,500',
    amountPaid: '₦1,000',
    paymentHistory: [{ amountNumber: 1_000 }, { amountNumber: 200 }],
    lastRollover: { startingBalance: 1_500, paymentHistoryStartIndex: 1 },
  };
  assert.equal(getLoanOutstanding(loan), 1_300);
});

test('a partially covered collateral sale keeps the remaining debt outstanding', () => {
  const loan = { loanState: 'Running', balance: '₦800,000', totalPayable: 2_000_000, disbursed: true, paymentHistory: [{ amountNumber: 1_200_000 }] };
  assert.equal(getLoanOutstanding(loan), 800_000);
});


test('rollover adds months to existing duration and charges interest per additional month on original principal', () => {
  const result = calculateRollover({ principal: 1_000_000, monthlyRatePercent: 10, additionalMonths: 2, currentDurationMonths: 3, currentTotalInterest: 300_000, currentTotalPayable: 1_300_000, currentOutstanding: 1_000_000, paidNow: 0 });
  assert.equal(result.valid, true);
  assert.equal(result.additionalInterest, 200_000);
  assert.equal(result.revisedDurationMonths, 5);
  assert.equal(result.revisedTotalInterest, 500_000);
  assert.equal(result.revisedTotalPayable, 1_500_000);
  assert.equal(result.revisedOutstanding, 1_200_000);
});

test('rollover works when original interest is unpaid and subtracts only an actual payment recorded during rollover', () => {
  const result = calculateRollover({ principal: 1_000_000, monthlyRatePercent: 10, additionalMonths: 1, currentDurationMonths: 3, currentTotalInterest: 300_000, currentTotalPayable: 1_300_000, currentOutstanding: 1_300_000, paidNow: 100_000 });
  assert.equal(result.valid, true);
  assert.equal(result.additionalInterest, 100_000);
  assert.equal(result.revisedDurationMonths, 4);
  assert.equal(result.revisedOutstanding, 1_300_000);
});
