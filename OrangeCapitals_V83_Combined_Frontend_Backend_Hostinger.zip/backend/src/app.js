import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { randomUUID, randomBytes, timingSafeEqual } from 'node:crypto';
import { db } from './db.js';

const routerFactory = express.Router;
const COLLECTIONS = ['customers','businessDevelopment','investors','records','roles','messages','tasks','loans','inventory','vehicles','notifications','recordTickets','workflow'];
const KV_KEYS = ['teamOrder','financialDashboard'];
const BRANCHES = new Set(['Lagos','Abuja','Both']);
const ROLES = new Set(['Credit Officer','Asset Verifier','Operations Officer','Recovery Officer','Data & IT Officer']);
const TEAMS = new Set(['Credit and Risk Management','Asset and Risk Management','Audit and Operations','Credit and Funds Transfer','Loan Recovery','Business Development','All teams']);
const MODULES = ['Expenses','Dashboard','Assigned Customers','Applications','Customers','New Application','Old Inventory','Loans','Loan Recovery','Vehicle Documents','Vehicles & Collateral','Financials','Audit & Activity','CAP GAIN','Company Records','Messages','Staff Dashboards','Business Development','Marketers','Users & Roles','Reports','Administration'];
const EMPTY_DASH = { totalLoanDisbursed:'₦0', totalInvestment:'₦0', activeLoan:'₦0', expectedInterest:'₦0', commissionPaid:'₦0' };
const ROLE_MODULES = {
  'Credit Officer':['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Loan Recovery','Vehicle Documents','Messages'],
  'Asset Verifier':['Dashboard','New Application','Assigned Customers','Old Inventory','Vehicle Documents','Company Records','Messages'],
  'Recovery Officer':['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Loan Recovery','Vehicle Documents','Messages'],
  'Operations Officer':['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Loan Recovery','Vehicle Documents','Messages'],
  'Data & IT Officer':['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Vehicle Documents','Messages']
};
const moduleFor = { customers:'Customers',businessDevelopment:'Business Development',investors:'CAP GAIN',records:'Company Records',roles:'Users & Roles',messages:'Messages',tasks:'Dashboard',loans:'Loans',inventory:'Old Inventory',vehicles:'Vehicles & Collateral',notifications:'Dashboard',recordTickets:'Company Records',workflow:'Dashboard' };
const json = value => { try { return JSON.parse(value); } catch { return null; } };
const asArray = value => Array.isArray(value) ? value : [];
const isAdmin = user => user.role === 'Main Administrator';
const publicUser = u => ({ id:u.id, name:u.name, email:u.email, role:u.role, team:u.team, branch:u.branch, active:Boolean(u.active), accessModules:json(u.access_modules)||u.accessModules||undefined, viewOnlyModules:json(u.view_only_modules)||u.viewOnlyModules||[] });
function safeEqual(a,b) { const x=Buffer.from(String(a||'')); const y=Buffer.from(String(b||'')); return x.length===y.length && timingSafeEqual(x,y); }
function cookieOptions() { return { httpOnly:true, secure:process.env.NODE_ENV==='production', sameSite:'lax', path:'/', maxAge:7*24*60*60*1000 }; }
function sign(user) { const secret=process.env.JWT_SECRET; if(!secret || secret.length<48) throw new Error('JWT_SECRET must contain at least 48 characters.'); return jwt.sign({ sub:user.id }, secret, { expiresIn:'7d', issuer:'orange-capitals' }); }
function authRequired(req,res,next) {
  try {
    const token=req.cookies?.oc_session || (String(req.headers.authorization||'').startsWith('Bearer ')?req.headers.authorization.slice(7):'');
    if(!token) return res.status(401).json({error:'Sign in to continue.'});
    const secret=process.env.JWT_SECRET;
    if(!secret || secret.length<48) return res.status(503).json({error:'Server authentication is not configured.'});
    const decoded=jwt.verify(token,secret,{issuer:'orange-capitals'});
    db().execute('SELECT * FROM oc_users WHERE id=? LIMIT 1',[decoded.sub]).then(([rows])=>{
      const u=rows[0]; if(!u || !u.active) return res.status(401).json({error:'Your account is inactive or your session has expired.'});
      req.user=publicUser(u); req.user.passwordHash=u.password_hash; next();
    }).catch(next);
  } catch { return res.status(401).json({error:'Your session is invalid or expired. Please sign in again.'}); }
}
function adminOnly(req,res,next) { if(!isAdmin(req.user)) return res.status(403).json({error:'Only the Main Administrator can perform this action.'}); next(); }
function canAccess(user,module,write=false) {
  if(isAdmin(user)) return true;
  const access=Array.isArray(user.accessModules) ? user.accessModules : (ROLE_MODULES[user.role] || []);
  if(!access.includes(module)) return false;
  if(write && Array.isArray(user.viewOnlyModules) && user.viewOnlyModules.includes(module)) return false;
  return true;
}
function branchAllowed(user, branch) { return isAdmin(user) || user.branch==='Both' || branch===user.branch; }
function docBranch(doc,user) {
  const raw=String(doc?.branch || doc?.location || '').trim();
  const normalized=raw.toLowerCase()==='lagos'?'Lagos':raw.toLowerCase()==='abuja'?'Abuja':raw.toLowerCase()==='both'?'Both':'';
  return normalized || (user.branch==='Both'?'Lagos':user.branch);
}
async function audit(user,action,summary,req) {
  await db().execute('INSERT INTO oc_audit_logs (user_id,user_name,action,summary,branch,ip_address) VALUES (?,?,?,?,?,?)',[user?.id||null,user?.name||'System',action,String(summary).slice(0,500),user?.branch||'Both',String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'').split(',')[0].slice(0,64)]);
}
function role(id,name,allowed) { return {id,name,description:`${name} access profile`,permissions:Object.fromEntries(MODULES.map(m=>[m,allowed.includes(m)]))}; }
const DEFAULT_ROLES=[role('ROLE-ADMIN','Main Administrator',MODULES),role('ROLE-CREDIT','Credit Officer',['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Loan Recovery','Vehicle Documents','Messages']),role('ROLE-ASSET','Asset Verifier',['Dashboard','New Application','Assigned Customers','Old Inventory','Vehicle Documents','Company Records','Messages']),role('ROLE-RECOVERY','Recovery Officer',['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Loan Recovery','Vehicle Documents','Messages']),role('ROLE-OPERATIONS','Operations Officer',['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Loan Recovery','Vehicle Documents','Messages']),role('ROLE-DATA','Data & IT Officer',['Dashboard','New Application','Assigned Customers','Old Inventory','Loans','Vehicle Documents','Messages'])];

export function createBackend() {
  const r=routerFactory();
  r.get('/health',async(req,res)=>{try{await db().query('SELECT 1');res.json({ok:true,service:'orange-capitals-api',database:'connected',mode:'hostinger-mysql'});}catch(e){res.status(503).json({ok:false,service:'orange-capitals-api',database:'unavailable',error:'Database connection failed.'});}});

  r.post('/auth/bootstrap-admin',async(req,res)=>{
    try {
      const expected=process.env.ADMIN_BOOTSTRAP_SECRET;
      if(!expected || !safeEqual(req.headers['x-bootstrap-secret'],expected)) return res.status(403).json({error:'Bootstrap authorization failed.'});
      const name=String(req.body?.name||'').trim(), email=String(req.body?.email||'').trim().toLowerCase(), password=String(req.body?.password||'');
      if(name.length<2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:'Provide a valid administrator name and email.'});
      if(password.length<14 || !/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) return res.status(400).json({error:'Administrator password must be at least 14 characters and contain letters and numbers.'});
      const pool=db();const lockConn=await pool.getConnection();let lockAcquired=false;let user;
      try {
        const [[lock]]=await lockConn.query("SELECT GET_LOCK('orange_capitals_first_admin',10) AS acquired");
        if(Number(lock.acquired)!==1)return res.status(503).json({error:'Administrator setup is busy. Try again shortly.'});
        lockAcquired=true;
        const [existing]=await lockConn.execute("SELECT id FROM oc_users WHERE role='Main Administrator' LIMIT 1");
        if(existing.length)return res.status(409).json({error:'A Main Administrator already exists. Bootstrap is disabled.'});
        user={id:randomUUID(),name,email,role:'Main Administrator',team:'All teams',branch:'Both',active:true,accessModules:MODULES,viewOnlyModules:[]};
        const hash=await bcrypt.hash(password,12);
        await lockConn.execute('INSERT INTO oc_users (id,name,email,password_hash,role,team,branch,active,access_modules,view_only_modules) VALUES (?,?,?,?,?,?,?,?,?,?)',[user.id,name,email,hash,user.role,user.team,user.branch,1,JSON.stringify(MODULES),JSON.stringify([])]);
      } finally {
        if(lockAcquired)await lockConn.query("SELECT RELEASE_LOCK('orange_capitals_first_admin')");
        lockConn.release();
      }
      res.status(201).json({message:'First administrator created. Remove ADMIN_BOOTSTRAP_SECRET from the hosting environment now.',user});
    } catch(e) { if(e.code==='ER_DUP_ENTRY') return res.status(409).json({error:'An account already exists for this email.'}); console.error(e);res.status(500).json({error:'Could not create the first administrator.'}); }
  });

  r.post('/auth/login',async(req,res)=>{
    try {
      const email=String(req.body?.email||'').trim().toLowerCase(), password=String(req.body?.password||'');
      if(!email||!password) return res.status(400).json({error:'Enter your email and password.'});
      const [rows]=await db().execute('SELECT * FROM oc_users WHERE email=? LIMIT 1',[email]); const u=rows[0];
      if(!u || !u.active || !(await bcrypt.compare(password,u.password_hash))) { await audit(null,'login_failed',`Failed login attempt for ${email}`,req).catch(()=>{}); return res.status(401).json({error:'Email or password is incorrect.'}); }
      res.cookie('oc_session',sign(u),cookieOptions()); await audit(publicUser(u),'login','Staff login successful',req);
      res.set('Cache-Control','no-store').json({user:publicUser(u)});
    } catch(e) { console.error(e);res.status(500).json({error:'Unable to sign in. Please try again.'}); }
  });
  r.post('/auth/logout',(req,res)=>{res.clearCookie('oc_session',{...cookieOptions(),maxAge:0});res.json({ok:true});});
  r.get('/me',authRequired,(req,res)=>res.set('Cache-Control','no-store').json(req.user));

  r.post('/auth/register',authRequired,adminOnly,async(req,res)=>{
    try {
      const name=String(req.body?.name||'').trim(),email=String(req.body?.email||'').trim().toLowerCase(),password=String(req.body?.password||''),role=String(req.body?.role||''),team=String(req.body?.team||''),branch=String(req.body?.branch||'Lagos');
      if(name.length<2)return res.status(400).json({error:'Enter the staff member’s full name.'});
      if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({error:'Enter a valid staff email address.'});
      if(password.length<12||!/[A-Za-z]/.test(password)||!/[0-9]/.test(password))return res.status(400).json({error:'Use a temporary password of at least 12 characters containing letters and numbers.'});
      if(!ROLES.has(role)||!TEAMS.has(team)||!BRANCHES.has(branch))return res.status(400).json({error:'Choose a valid role, team and branch.'});
      const id=randomUUID(),hash=await bcrypt.hash(password,12);
      await db().execute('INSERT INTO oc_users (id,name,email,password_hash,role,team,branch,active,access_modules,view_only_modules) VALUES (?,?,?,?,?,?,?,?,?,?)',[id,name,email,hash,role,team,branch,1,null,JSON.stringify([])]);
      const user={id,name,email,role,team,branch,active:true,viewOnlyModules:[]};await audit(req.user,'staff_created',`Created staff account ${email}`,req);res.status(201).json({user});
    } catch(e){if(e.code==='ER_DUP_ENTRY')return res.status(409).json({error:'A staff account already exists for this email.'});console.error(e);res.status(500).json({error:'Could not create staff account.'});}
  });

  r.get('/bootstrap',authRequired,async(req,res)=>{
    try {
      const docs={};
      for(const collection of COLLECTIONS){
        if(!canAccess(req.user,moduleFor[collection]||'Dashboard')){docs[collection]=[];continue;}
        const [rows]=await db().execute('SELECT doc_id,branch,payload FROM oc_documents WHERE collection_name=? ORDER BY updated_at DESC',[collection]);
        docs[collection]=rows.filter(row=>branchAllowed(req.user,row.branch)).map(row=>json(row.payload)).filter(Boolean);
      }
      docs.roles=isAdmin(req.user)?(docs.roles?.length?docs.roles:DEFAULT_ROLES):[];
      const [settings]=await db().execute('SELECT setting_key,payload FROM oc_settings WHERE setting_key IN (?,?)',KV_KEYS);
      const kv=Object.fromEntries(settings.map(x=>[x.setting_key,json(x.payload)]));
      kv.teamOrder??=[];kv.financialDashboard??={...EMPTY_DASH};
      let staff=[req.user];
      if(isAdmin(req.user)){const [users]=await db().query('SELECT * FROM oc_users ORDER BY created_at');staff=users.map(publicUser);}
      const [[seqRow]]=await db().query('SELECT COALESCE(MAX(seq),0) AS seq FROM oc_change_log');
      res.set('Cache-Control','no-store').json({docs,staff,kv,serverSeq:Number(seqRow.seq),authOnly:false});
    }catch(e){console.error(e);res.status(500).json({error:'Unable to load company records.'});}
  });

  r.post('/sync',authRequired,async(req,res)=>{
    const changes=Array.isArray(req.body?.changes)?req.body.changes:[], kv=req.body?.kv||{};
    if(changes.length>300)return res.status(413).json({error:'Too many changes in one request.'});
    const conn=await db().getConnection();
    try {
      await conn.beginTransaction();
      for(const change of changes){
        const collection=String(change.collection||'');if(!COLLECTIONS.includes(collection))throw Object.assign(new Error('Unknown data collection.'),{status:400});
        const module=moduleFor[collection]||'Dashboard';if(!canAccess(req.user,module,true))throw Object.assign(new Error(`You do not have permission to edit ${module}.`),{status:403});
        for(const doc of asArray(change.upserts)){
          if(!doc || doc.id===undefined || doc.id===null)throw Object.assign(new Error('Every record must have an ID.'),{status:400});
          const branch=docBranch(doc,req.user);if(!BRANCHES.has(branch)||!branchAllowed(req.user,branch))throw Object.assign(new Error('You cannot save records for this branch.'),{status:403});
          const value={...doc,branch};const payload=JSON.stringify(value);if(payload.length>8_000_000)throw Object.assign(new Error('A record is too large to save. Store large files in secure file storage.'),{status:413});
          const [existing]=await conn.execute('SELECT branch FROM oc_documents WHERE collection_name=? AND doc_id=? FOR UPDATE',[collection,String(doc.id)]);
          if(existing[0]&&!branchAllowed(req.user,existing[0].branch))throw Object.assign(new Error('You cannot modify this branch record.'),{status:403});
          await conn.execute('INSERT INTO oc_documents (collection_name,doc_id,branch,payload,updated_by) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE branch=VALUES(branch),payload=VALUES(payload),updated_by=VALUES(updated_by)',[collection,String(doc.id),branch,payload,req.user.id]);
          await conn.execute("INSERT INTO oc_change_log (collection_name,doc_id,operation,branch,payload) VALUES (?,?,'upsert',?,?)",[collection,String(doc.id),branch,payload]);
        }
        for(const id of asArray(change.deletes)){
          const [rows]=await conn.execute('SELECT branch FROM oc_documents WHERE collection_name=? AND doc_id=?',[collection,String(id)]);
          if(rows[0]&&!branchAllowed(req.user,rows[0].branch))throw Object.assign(new Error('You cannot delete this branch record.'),{status:403});
          await conn.execute('DELETE FROM oc_documents WHERE collection_name=? AND doc_id=?',[collection,String(id)]);
          await conn.execute("INSERT INTO oc_change_log (collection_name,doc_id,operation,branch) VALUES (?,?,'delete',?)",[collection,String(id),rows[0]?.branch||req.user.branch]);
        }
      }
      for(const [key,value] of Object.entries(kv)){
        if(!KV_KEYS.includes(key))throw Object.assign(new Error('Unknown settings key.'),{status:400});
        if(!canAccess(req.user,'Dashboard',true))throw Object.assign(new Error('You do not have permission to edit dashboard settings.'),{status:403});
        await conn.execute('INSERT INTO oc_settings (setting_key,payload,updated_by) VALUES (?,?,?) ON DUPLICATE KEY UPDATE payload=VALUES(payload),updated_by=VALUES(updated_by)',[key,JSON.stringify(value),req.user.id]);
      }
      await conn.commit();await audit(req.user,'data_sync',`Saved ${changes.length} collection update(s)`,req);res.json({ok:true});
    }catch(e){await conn.rollback();res.status(e.status||500).json({error:e.status?e.message:'Unable to save records. Please retry.'});}finally{conn.release();}
  });

  r.get('/sync/changes',authRequired,async(req,res)=>{
    try {
      const since=Math.max(0,Number(req.query.since||0));const docs={},deleted={},kv={};
      const [rows]=await db().execute('SELECT * FROM oc_change_log WHERE seq>? ORDER BY seq LIMIT 2000',[since]);
      for(const row of rows){const collection=row.collection_name;if(!COLLECTIONS.includes(collection)||!canAccess(req.user,moduleFor[collection]||'Dashboard')||!branchAllowed(req.user,row.branch))continue;
        if(row.operation==='delete'){(deleted[collection]??=[]).push(row.doc_id);}else{(docs[collection]??=[]).push(json(row.payload));}
      }
      const [settings]=await db().execute('SELECT setting_key,payload FROM oc_settings WHERE setting_key IN (?,?)',KV_KEYS);for(const s of settings)kv[s.setting_key]=json(s.payload);
      const [[seqRow]]=await db().query('SELECT COALESCE(MAX(seq),0) AS seq FROM oc_change_log');
      let staff=[];if(isAdmin(req.user)){const [users]=await db().query('SELECT * FROM oc_users ORDER BY created_at');staff=users.map(publicUser);}
      res.set('Cache-Control','no-store').json({docs,deleted,kv,staff,serverSeq:Number(seqRow.seq)});
    }catch(e){console.error(e);res.status(500).json({error:'Unable to retrieve updates.'});}
  });

  r.get('/users',authRequired,adminOnly,async(req,res)=>{const [rows]=await db().query('SELECT * FROM oc_users ORDER BY created_at');res.json(rows.map(publicUser));});
  r.patch('/users/:id',authRequired,adminOnly,async(req,res)=>{
    try{
      const [rows]=await db().execute('SELECT * FROM oc_users WHERE id=?',[req.params.id]);if(!rows[0])return res.status(404).json({error:'Staff account not found.'});
      const u=rows[0],b=req.body||{};const name=b.name===undefined?u.name:String(b.name).trim(),role=b.role===undefined?u.role:String(b.role),team=b.team===undefined?u.team:String(b.team),branch=b.branch===undefined?u.branch:String(b.branch),active=b.active===undefined?Boolean(u.active):Boolean(b.active);
      if(!ROLES.has(role) && !(u.role==='Main Administrator' && role==='Main Administrator'))return res.status(400).json({error:'Invalid staff role. Administrator privileges cannot be assigned through staff management.'});if(!TEAMS.has(team)||!BRANCHES.has(branch))return res.status(400).json({error:'Invalid team or branch.'});
      const access=b.accessModules===undefined?json(u.access_modules):asArray(b.accessModules),view=b.viewOnlyModules===undefined?(json(u.view_only_modules)||[]):asArray(b.viewOnlyModules);
      await db().execute('UPDATE oc_users SET name=?,role=?,team=?,branch=?,active=?,access_modules=?,view_only_modules=? WHERE id=?',[name,role,team,branch,active?1:0,access?JSON.stringify(access):null,JSON.stringify(view),req.params.id]);
      const [updated]=await db().execute('SELECT * FROM oc_users WHERE id=?',[req.params.id]);await audit(req.user,'staff_updated',`Updated staff account ${updated[0].email}`,req);res.json({user:publicUser(updated[0])});
    }catch(e){console.error(e);res.status(500).json({error:'Could not update staff account.'});}
  });
  r.patch('/users/:id/password',authRequired,adminOnly,async(req,res)=>{const password=String(req.body?.password||'');if(password.length<12||!/[A-Za-z]/.test(password)||!/[0-9]/.test(password))return res.status(400).json({error:'Password must be at least 12 characters and contain letters and numbers.'});const hash=await bcrypt.hash(password,12);const [result]=await db().execute('UPDATE oc_users SET password_hash=? WHERE id=?',[hash,req.params.id]);if(!result.affectedRows)return res.status(404).json({error:'Staff account not found.'});await audit(req.user,'password_reset',`Reset staff password for ${req.params.id}`,req);res.json({ok:true});});
  r.get('/audit',authRequired,async(req,res)=>{if(!canAccess(req.user,'Audit & Activity'))return res.status(403).json({error:'You do not have access to audit activity.'});const [rows]=await db().execute('SELECT user_name,action,summary,UNIX_TIMESTAMP(created_at)*1000 AS ts,branch FROM oc_audit_logs WHERE (?=1 OR branch=? OR branch="Both") ORDER BY id DESC LIMIT 1000',[isAdmin(req.user)?1:0,req.user.branch]);res.json(rows.map(x=>({user_name:x.user_name,action:x.action,summary:x.summary,ts:Number(x.ts),branch:x.branch})));});

  r.get('/public/investor/:token',async(req,res)=>{res.status(501).json({error:'Investor portal token access will be enabled after investor-specific secure login is configured.'});});
  return r;
}
