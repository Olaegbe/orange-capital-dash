CREATE TABLE IF NOT EXISTS oc_users (
  id CHAR(36) PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(80) NOT NULL,
  team VARCHAR(100) NOT NULL DEFAULT 'All teams',
  branch VARCHAR(20) NOT NULL DEFAULT 'Lagos',
  active TINYINT(1) NOT NULL DEFAULT 1,
  access_modules JSON NULL,
  view_only_modules JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oc_documents (
  collection_name VARCHAR(80) NOT NULL,
  doc_id VARCHAR(190) NOT NULL,
  branch VARCHAR(20) NOT NULL DEFAULT 'Lagos',
  payload LONGTEXT NOT NULL,
  updated_by CHAR(36) NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (collection_name, doc_id),
  KEY idx_oc_docs_branch (collection_name, branch),
  CONSTRAINT fk_oc_docs_user FOREIGN KEY (updated_by) REFERENCES oc_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oc_settings (
  setting_key VARCHAR(120) PRIMARY KEY,
  payload LONGTEXT NOT NULL,
  updated_by CHAR(36) NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_oc_settings_user FOREIGN KEY (updated_by) REFERENCES oc_users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oc_change_log (
  seq BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  collection_name VARCHAR(80) NOT NULL,
  doc_id VARCHAR(190) NOT NULL,
  operation ENUM('upsert','delete') NOT NULL,
  branch VARCHAR(20) NOT NULL DEFAULT 'Lagos',
  payload LONGTEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_oc_change_seq (seq),
  KEY idx_oc_change_branch (branch, seq)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS oc_audit_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id CHAR(36) NULL,
  user_name VARCHAR(160) NOT NULL,
  action VARCHAR(100) NOT NULL,
  summary VARCHAR(500) NOT NULL,
  branch VARCHAR(20) NOT NULL DEFAULT 'Both',
  ip_address VARCHAR(64) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_oc_audit_created (created_at),
  KEY idx_oc_audit_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
